Follow these steps to set up your project:

1. Install node.js [https://nodejs.org/](https://nodejs.org/) using the latest version (6.5.0)

2. Clone

		git clone git@git.tecnotree.com:tec_common/ttui-app-starter.git my-app && cd my-app
3. Install npm packages

		npm install
4. Install bower dependencies

		bower install
5. Run grunt tasks

		grunt build serve

Then open your favourite web browser and navigate to [http://localhost:3000](http://localhost:3000).