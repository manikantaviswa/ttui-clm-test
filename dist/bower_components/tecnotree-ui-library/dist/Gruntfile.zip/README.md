# Tecnotree Common UI Library

## Online documentation

Up-to-date documentation is available here: http://192.168.32.140/uilib/origin/develop/

### Offline documentation

Navigate to `docs/_includes/developers-guide/setup.md` to find out how to run local documentation server
