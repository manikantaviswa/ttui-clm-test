'use strict';

angular.module('TT-UI.Common.Filters', [
	'TT-UI.Common.Filters.DateFilter',
	'TT-UI.Common.Filters.ObjectFieldFilter',
	'TT-UI.Common.Filters.RegExpFilter'
]);