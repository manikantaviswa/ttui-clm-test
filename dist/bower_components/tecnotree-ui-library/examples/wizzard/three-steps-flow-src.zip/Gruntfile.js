module.exports = function(grunt) {
	'use strict';

	require('load-grunt-tasks')(grunt);
	require('time-grunt')(grunt);
	grunt.loadNpmTasks('grunt-wiredep');

	// Define the configuration for all the tasks
	grunt.initConfig({

		pkg: grunt.file.readJSON('package.json'),

		// The actual grunt server settings
		connect: {
			options: {
				port: 8000,
				// Change this to '0.0.0.0' to access the server from outside.
				hostname: 'localhost',
				livereload: 35730
			},
			livereload: {
				options: {
					base: 'src/'
				}
			}
		},

		// Watches files for changes and runs tasks based on the changed files
		watch: {
			livereload: {
				options: {
					livereload: 35730,
					interval: 500,
					debounceDelay: 500
				},
				files: [
					'src/scripts/**/*.js',
					'src/scripts/**/*.html',
					'src/*.html'
				]
			}
		},

		// Empties folders to start fresh
		clean: {
			dist: 'dist/',
			'embedded': 'dist-embedded',
			server: '.tmp'
		},

		// Install bower components
		bower: {
			install: {
				options: {
					copy: false
				}
			}
		},

		// Automatically inject Bower components into the app
		wiredep: {
			app: {
				src: [
					'src/*.html'
				],
				options: {
					exclude: [
						'bower_components/bootstrap/'
					]
				}
			}
		},

		// Copies remaining files to places other tasks can use
		copy: {
			dist: {
				expand: true,
				dot: true,
				cwd: 'src/',
				dest: 'dist',
				src: ['**']
			},
			embedded: {
				expand: true,
				dot: true,
				cwd: 'src/',
				dest: 'dist-embedded',
				src: ['**', '!bower_components/**']
			},
		},

		compress: {
			main: {
				options: {
					archive: 'three-steps-flow-src.zip'
				},
				files: [
					{
						src: ['Gruntfile.js', 'bower.json', 'package.json', '.bowerrc', 'src/**', '!src/bower_components/**'], 
						dest: '/'},
				]
			}
		},

		replace: {
			embedded: {
				options: {
					patterns: [
						{
							match: /src=\"bower_components/g,
							replacement: function(search, match) {
								return 'src="../../../dist/bower_components';
							}
						},
						{
							match: /=\"bower_components\/tecnotree-ui-library\/dist/g,
							replacement: function(search, match) {
								return '="../../../dist';
							}
						}
					]
				},

				files: [{
					src: 'dist-embedded/index.html',
					dest: 'dist-embedded/index.html'
				}]
			}
		}
	});

	grunt.registerTask('build', 
		['clean:dist', 'bower', 'wiredep', 'copy:dist']);

	grunt.registerTask('serve',
		['build', 'connect:livereload', 'watch:livereload'])

	grunt.registerTask('build-embedded',
		['compress', 'clean:embedded', 'bower', 'wiredep', 'copy:embedded', 'replace:embedded']);

	grunt.registerTask('default', [
		'build-embedded'
	]);

};
